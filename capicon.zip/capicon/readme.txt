# humanstxt.org/
# The humans responsible & technology colophon

# DONATIONS
	
	Thank you all for appreciating so much the hard work done on this product to the point of paying for it. I Hope you enjoy it! 

	Sebastian Hermida
	Manuel Jesús Recena Soto
	Atle Lillehovde
	Gabor Meszoly
	Nils Schirmer
	Mark Gavagan
	Daniel Jacoby
    K Media Ltd
    Ho Byyung Kim
    Stegaru Victor
    Mario Gutierrez
    Andrzej Piłatowicz
    Pascal Casti
    Philipp Munzert
    Sybille Paumier
    Laura Portillo Artacho
    Geoffrey Parker
    H-Joachim Janduda
    Brigitta Settels
    Premper Agencia Digital
    Sören Hänsler
    Gary Vey
    Robert Gampe

# TEAM

    Mario del Valle Guijarro -- Designer & Illustrator  -- @maduil

# THANKS

	To my parents and brother for educating me in the best way.

	My grandfather for teaching me that with determination, perseverance and work are achieved goals.

	My girlfriend Sandra for supporting me in all the process and always trust my.

	To Mario de Frutos Dieguez (@ethervoid), Javier Gamarra Olmedo (@nhpatt) and Jorge Maroto García (@patoroco) support me in this project without asking anything in return and to encourage me at all times.

	My users that share this project without stopping and they are the piece important thing to design, User Interface Design, Forever :)

# TEAMWORK & REVIEWS
	
	Thank you all for supporting as voluntaries for improve this project.

	Carlos Puchol have collaborated in the work of improving text translation to english.

# TECHNOLOGY COLOPHON

    HTML5, CSS3
    Normalize.css, jQuery, Modernizr